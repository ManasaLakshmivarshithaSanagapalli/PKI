﻿namespace RootCAAPI.Models
{
    public class CertificateAuthority
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = "";
        public bool IsRoot { get; set; }
        public Guid? ParentCAId { get; set; }
        public string SubjectDN { get; set; } = "";
        public string CertificatePem { get; set; } = "";
        public string Algorithm { get; set; } = "RSA";
        public string? Curve { get; set; }
        public int? KeySize { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ExpiresAt { get; set; }

        // 🔐 Secure columns
        public string? EncryptedPrivateKeyPem { get; set; }
        public string? PublicKeyPem { get; set; }
        public bool IsRevoked { get; set; } = false;
        public DateTime? RevokedAt { get; set; }
    }

}
