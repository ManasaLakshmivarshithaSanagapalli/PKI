﻿namespace RootCAAPI.Models
{
    public class EndEntitym
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public Guid IntermediateCAId { get; set; }
        public string SubjectDN { get; set; } = string.Empty;
        public string Algorithm { get; set; } = string.Empty;
        public string? Curve { get; set; }
        public int? KeySize { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ExpiresAt { get; set; }
        public string CertificatePem { get; set; } = string.Empty;
        public string? EncryptedPrivateKeyPem { get; set; }
        public string? PublicKeyPem { get; set; }
        public bool IsRevoked { get; set; } = false;
        public DateTime? RevokedAt { get; set; }
        
    }
}
