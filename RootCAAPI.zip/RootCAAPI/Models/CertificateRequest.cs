﻿namespace RootCAAPI.Models
{
    public class CertificateRequest
    {
        public Guid Id { get; set; }
    }
}

