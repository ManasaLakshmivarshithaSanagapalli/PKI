﻿namespace RootCAAPI.Models
{
    public class OCSPResponder
    {
            public Guid Id { get; set; }
            public Guid IntermediateCAId { get; set; } // linked to Intermediate CA
            public string SubjectDN { get; set; }
            public string CertificatePem { get; set; }
            public string PublicKeyPem { get; set; }
            public string EncryptedPrivateKeyPem { get; set; }
            public DateTime CreatedAt { get; set; }
            public DateTime ExpiresAt { get; set; }
            public bool IsActive { get; set; }

            public string Algorithm { get; set; } = string.Empty;

    }
}
