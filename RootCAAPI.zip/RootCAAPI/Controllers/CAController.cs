﻿using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using RootCAAPI.Contracts;
using RootCAAPI.Data;
using RootCAAPI.Models;
using RootCAAPI.Services;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.X509;
using System.Text;
using Org.BouncyCastle.Ocsp;
using Org.BouncyCastle.Asn1.Ocsp;
namespace RootCAAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CAController : ControllerBase
    {
        private readonly PkiDbContext _db; // Root DB
        private readonly IntermediateDBContext _intermediateDb; // Intermediate DB
        private readonly EndEntityDBContext _endentityDb; //endentityDB
        private readonly CertificateService _svc; 
        private readonly OCSPDBContext _ocspDB; //OCSPDB
        private readonly KeyencryptionService _keyencryption;
        private readonly OcspService _ocspService;

        public CAController(PkiDbContext db, IntermediateDBContext intermediateDb,EndEntityDBContext endDB, CertificateService svc, OCSPDBContext ocspDB, KeyencryptionService keyencryption, OcspService ocspService)
        {
            _db = db;
            _intermediateDb = intermediateDb;
            _endentityDb = endDB;
            _svc = svc;
            _ocspDB = ocspDB;
            _keyencryption = keyencryption;
            _ocspService = ocspService;
        }

        [HttpPost("root")]
        public async Task<IActionResult> CreateRoot([FromBody] CreateRootCaRequest request, [FromServices] KeyencryptionService encryptor)
        {
            var (cert, key, algo, keySize, curve, privatePem, publicPem) = _svc.CreateRootCA(request);
            string encryptedPrivateKey = encryptor.Encrypt(privatePem);

            string certPem = CertificateService.ToPem(cert.Export(X509ContentType.Cert), "CERTIFICATE")
                              .Replace("\r\n", "\n");

            var ca = new CertificateAuthority
            {
                Id = Guid.NewGuid(),
                Name = request.Name,
                IsRoot = true,
                SubjectDN = request.SubjectDN,
                CertificatePem = certPem.Trim(),
                Algorithm = algo,
                KeySize = keySize,
                Curve = curve,
                CreatedAt = cert.NotBefore,
                ExpiresAt = cert.NotAfter,
                EncryptedPrivateKeyPem = encryptedPrivateKey.Trim(),
                PublicKeyPem = publicPem.Trim()
            };

            _db.CAs.Add(ca);
            await _db.SaveChangesAsync();

            return Ok(new
            {
                id = ca.Id,
                ca.Name,
                ca.Algorithm,
                ca.KeySize,
                ca.Curve,
                ca.CertificatePem,
                ca.PublicKeyPem,
                EncryptedPrivateKeyPem = ca.EncryptedPrivateKeyPem,
                notBefore = ca.CreatedAt,
                notAfter = ca.ExpiresAt
            });
        }

        [HttpGet("ca/{id}/privatekey")]
        public async Task<IActionResult> GetDecryptedPrivateKey(Guid id, [FromServices] KeyencryptionService encryptor)
        {
            var ca = await _db.CAs.FindAsync(id);
            if (ca == null || string.IsNullOrEmpty(ca.EncryptedPrivateKeyPem))
                return NotFound("CA or private key not found.");

            try
            {
                var decryptedPem = encryptor.Decrypt(ca.EncryptedPrivateKeyPem);
                return Ok(new { privateKeyPem = decryptedPem });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = "Decryption failed", details = ex.Message });
            }
        }

        [HttpPost("intermediate")]
        public async Task<IActionResult> CreateIntermediate([FromBody] CreateIntermediateCaRequest request, [FromServices] KeyencryptionService encryptor)
        {
            // Load the issuer (Root CA) from Root DB
            var issuerCa = await _db.CAs.FindAsync(request.IssuerId);
            if (issuerCa == null)
                return NotFound("Issuer CA not found");

            // Decrypt Root private key
            var issuerPrivateKey = encryptor.Decrypt(issuerCa.EncryptedPrivateKeyPem);

            // Create Intermediate CA
            var (cert, certPem, publicPem, privatePem, algo, keySize, curve) =
                _svc.CreateIntermediateCA(request.SubjectDN, issuerCa.SubjectDN, issuerPrivateKey, request.Algorithm, request.KeySize, request.Curve, request.ValidYears);

            // Encrypt Intermediate private key
            var encryptedPrivateKey = encryptor.Encrypt(privatePem);

            // Save to Intermediate DB
            var intermediate = new CertificateAuthority
            {
                Id = Guid.NewGuid(),
                Name = request.Name,
                IsRoot = false,
                ParentCAId = issuerCa.Id, // Reference Root CA
                SubjectDN = request.SubjectDN,
                CertificatePem = certPem.Trim(),
                Algorithm = algo,
                KeySize = keySize,
                Curve = curve,
                CreatedAt = cert.NotBefore,
                ExpiresAt = cert.NotAfter,
                EncryptedPrivateKeyPem = encryptedPrivateKey.Trim(),
                PublicKeyPem = publicPem.Trim()
            };

            _intermediateDb.CAs.Add(intermediate);
            await _intermediateDb.SaveChangesAsync();

            return Ok(new
            {
                intermediate.Id,
                intermediate.Name,
                intermediate.Algorithm,
                intermediate.KeySize,
                intermediate.Curve,
                intermediate.CertificatePem,
                intermediate.PublicKeyPem,
                EncryptedPrivateKeyPem = intermediate.EncryptedPrivateKeyPem,
                notBefore = intermediate.CreatedAt,
                notAfter = intermediate.ExpiresAt
            });
        }
        [HttpPost("end")]
        public async Task<IActionResult> CreateEntity([FromBody] CreateEndEntityRequest request, [FromServices] KeyencryptionService encryptor)
        {
            // Load the issuer (Root CA) from Root DB
            var issuerCa = await _intermediateDb.CAs.FindAsync(request.IssuerId);
            if (issuerCa == null)
                return NotFound("Issuer CA not found");

            // Decrypt Root private key
            var issuerPrivateKey = encryptor.Decrypt(issuerCa.EncryptedPrivateKeyPem);

           
            var (cert, certPem, publicPem, privatePem, algo, keySize, curve) =
                _svc.CreateEndEntity(request.SubjectDN, issuerCa.SubjectDN, issuerPrivateKey, request.Algorithm, request.KeySize, request.Curve, request.ValidYears);

            // Encrypt Intermediate private key
            var encryptedPrivateKey = encryptor.Encrypt(privatePem);
            var entity = new EndEntitym
            {
                Id = Guid.NewGuid(),
                Name = request.Name,
                IntermediateCAId = issuerCa.Id, // link to issuer
                SubjectDN = request.SubjectDN,
                CertificatePem = certPem.Trim(),
                Algorithm = algo,
                KeySize = keySize,
                Curve = curve,
                CreatedAt = cert.NotBefore,
                ExpiresAt = cert.NotAfter,
                EncryptedPrivateKeyPem = encryptedPrivateKey.Trim(),
                PublicKeyPem = publicPem.Trim()
            };

            _endentityDb.EndEntities.Add(entity);
            await _endentityDb.SaveChangesAsync();


            return Ok(new
            {
                entity.Id,
                entity.Name,
                entity.Algorithm,
                entity.KeySize,
                entity.Curve,
                entity.CertificatePem,
                entity.PublicKeyPem,
                EncryptedPrivateKeyPem = entity.EncryptedPrivateKeyPem,
                notBefore = entity.CreatedAt,
                notAfter = entity.ExpiresAt
            });
        }
        [HttpGet("get")]
        public async Task<IActionResult> GetCertificate([FromQuery] Guid id)
        {
            if (id == Guid.Empty)
                return BadRequest("Certificate ID is required.");

            // Try Root DB
            var rootCa = await _db.CAs.FindAsync(id);
            if (rootCa != null)
            {
                return Ok(new
                {
                    rootCa.Id,
                    rootCa.Name,
                    rootCa.Algorithm,
                    rootCa.KeySize,
                    rootCa.Curve,
                    rootCa.CertificatePem,
                    rootCa.PublicKeyPem,
                    notBefore = rootCa.CreatedAt,
                    notAfter = rootCa.ExpiresAt,
                    rootCa.IsRevoked,
                    rootCa.RevokedAt,
                    Type = "RootCA"
                });
            }

            // …same for Intermediate and EndEntity…

            

        // Try Intermediate
        var intermediateCa = await _intermediateDb.CAs.FindAsync(id);
            if (intermediateCa != null)
            {
                return Ok(new
                {
                    intermediateCa.Id,
                    intermediateCa.Name,
                    intermediateCa.Algorithm,
                    intermediateCa.KeySize,
                    intermediateCa.Curve,
                    intermediateCa.CertificatePem,
                    intermediateCa.PublicKeyPem,
                    notBefore = intermediateCa.CreatedAt,
                    notAfter = intermediateCa.ExpiresAt,
                    intermediateCa.IsRevoked,
                    intermediateCa.RevokedAt,
                    Type = "IntermediateCA"
                });
            }

            // Try EndEntity
            var entity = await _endentityDb.EndEntities.FindAsync(id);
            if (entity != null)
            {
                return Ok(new
                {
                    entity.Id,
                    entity.Name,
                    entity.Algorithm,
                    entity.KeySize,
                    entity.Curve,
                    entity.CertificatePem,
                    entity.PublicKeyPem,
                    notBefore = entity.CreatedAt,
                    notAfter = entity.ExpiresAt,
                    entity.IsRevoked,
                    entity.RevokedAt,
                    Type = "EndEntity"
                });
            }

            return NotFound("Certificate not found");
        }

        [HttpPost("revoke/{id}")]
        public async Task<IActionResult> RevokeCertificate(Guid id)
        {
            if (id == Guid.Empty)
                return BadRequest("Certificate ID is required.");

            // Root
            var rootCa = await _db.CAs.FindAsync(id);
            if (rootCa != null)
            {
                if (rootCa.IsRevoked)
                    return BadRequest(new { message = "Certificate already revoked", revokedAt = rootCa.RevokedAt });

                rootCa.IsRevoked = true;
                rootCa.RevokedAt = DateTime.UtcNow;
                await _db.SaveChangesAsync();

                return Ok(new { message = "Root CA revoked successfully", id = rootCa.Id, revokedAt = rootCa.RevokedAt });
            }

            // Intermediate
            var intermediateCa = await _intermediateDb.CAs.FindAsync(id);
            if (intermediateCa != null)
            {
                if (intermediateCa.IsRevoked)
                    return BadRequest(new { message = "Certificate already revoked", revokedAt = intermediateCa.RevokedAt });

                intermediateCa.IsRevoked = true;
                intermediateCa.RevokedAt = DateTime.UtcNow;
                await _intermediateDb.SaveChangesAsync();

                return Ok(new { message = "Intermediate CA revoked successfully", id = intermediateCa.Id, revokedAt = intermediateCa.RevokedAt });
            }

            // EndEntity
            var entity = await _endentityDb.EndEntities.FindAsync(id);
            if (entity != null)
            {
                if (entity.IsRevoked)
                    return BadRequest(new { message = "Certificate already revoked", revokedAt = entity.RevokedAt });

                entity.IsRevoked = true;
                entity.RevokedAt = DateTime.UtcNow;
                await _endentityDb.SaveChangesAsync();

                return Ok(new { message = "End-entity certificate revoked successfully", id = entity.Id, revokedAt = entity.RevokedAt });
            }

            return NotFound("Certificate not found");
        }

        [HttpGet("roots")]
        public IActionResult GetAllRootCAs()
        {
            var roots = _db.CAs.ToList();
            return Ok(roots.Select(r => new {
                r.Id,
                r.Name,
                r.SubjectDN,
                r.Algorithm,
                r.KeySize,
                r.Curve,
                r.CreatedAt,
                r.ExpiresAt,
                r.IsRevoked
            }));
        }

        [HttpGet("intermediates")]
        public IActionResult GetAllIntermediateCAs()
        {
            var intermediates = _intermediateDb.CAs.ToList();
            return Ok(intermediates.Select(i => new {
                i.Id,
                i.Name,
                i.SubjectDN,
                i.ParentCAId,
                i.Algorithm,
                i.KeySize,
                i.Curve,
                i.CreatedAt,
                i.ExpiresAt,
                i.IsRevoked
            }));
        }
        [HttpGet("OCSPL")]
        public IActionResult GetAllOCSPCAs()
        {
            var ocsps = _ocspDB.OcspResponders.ToList();
            return Ok(ocsps.Select(o => new {
                o.Id,
                o.IntermediateCAId,
                o.SubjectDN,
                o.CertificatePem,
                o.EncryptedPrivateKeyPem,
                o.PublicKeyPem,
                o.CreatedAt,
                o.ExpiresAt,
                o.IsActive,
                o.Algorithm
            }));
        }
        [HttpGet("end")]
        public IActionResult GetAllEndCAs()
        {
            var end = _endentityDb.EndEntities.ToList();
            return Ok(end.Select(e => new {
                e.Id,
                e.Name,
                e.IntermediateCAId,
                e.SubjectDN,
                e.CertificatePem,
                e.EncryptedPrivateKeyPem,
                e.PublicKeyPem,
                e.CreatedAt,
                e.ExpiresAt,
                e.IsRevoked,
                e.Algorithm
            }));
        }

        [HttpPost("ocsp")]
        public async Task<IActionResult> CreateOcspResponder([FromBody] CreateOcspResponderRequest request, [FromServices] KeyencryptionService encryptor)
        {
            // 1. Find Intermediate CA issuer
            var issuerCa = await _intermediateDb.CAs.FindAsync(request.IntermediateCAId);
            if (issuerCa == null)
                return NotFound("Intermediate CA not found");

            // 2. Decrypt issuer private key
            var issuerPrivateKey = encryptor.Decrypt(issuerCa.EncryptedPrivateKeyPem);

            // 3. Create OCSP responder cert
            var (cert, certPem, publicPem, privatePem) = _svc.CreateOcspResponder(
                request.SubjectDN,
                issuerCa.SubjectDN,
                issuerPrivateKey,
                request.ValidYears,
                request.Algorithm,
                request.KeySize,
                request.Curve
            );

            // 4. Encrypt OCSP private key
            var encryptedPrivateKey = encryptor.Encrypt(privatePem);

            // 5. Save to OCSP DB
            var responder = new OCSPResponder
            {
                Id = Guid.NewGuid(),
                IntermediateCAId = issuerCa.Id,
                SubjectDN = request.SubjectDN,
                CertificatePem = certPem.Trim(),
                PublicKeyPem = publicPem.Trim(),
                EncryptedPrivateKeyPem = encryptedPrivateKey.Trim(),
                CreatedAt = cert.NotBefore,
                ExpiresAt = cert.NotAfter,
                Algorithm = request.Algorithm,
                IsActive = true
            };

            _ocspDB.OcspResponders.Add(responder);
            await _ocspDB.SaveChangesAsync();

            // 6. Return response
            return Ok(new
            {
                responder.Id,
                responder.IntermediateCAId,
                responder.SubjectDN,
                responder.CertificatePem,
                responder.PublicKeyPem,
                EncryptedPrivateKeyPem = responder.EncryptedPrivateKeyPem,
                responder.CreatedAt,
                responder.ExpiresAt,
                responder.Algorithm,
                responder.IsActive
            });
        }

        [HttpPost("ocsp/check")]
        public async Task<IActionResult> CheckOcsp([FromBody] OCSPCheckRequest req)
        {
            // 1. Find the issuer (Intermediate CA)
            var intermediate = await _intermediateDb.CAs.FindAsync(req.IntermediateCAId);
            if (intermediate == null)
                return NotFound("Intermediate CA not found");

            // 2. Find OCSP responder for this intermediate
            var responder = await _ocspDB.OcspResponders
                .FirstOrDefaultAsync(r => r.IntermediateCAId == req.IntermediateCAId && r.IsActive);
            if (responder == null)
                return NotFound("No OCSP responder found for this CA");

            // 3. Find the end-entity cert
            var cert = await _endentityDb.EndEntities.FindAsync(req.EndEntityCertId);
            if (cert == null)
                return Ok(new { Status = "unknown" });

            // 4. Decide status
            string status = cert.IsRevoked ? "revoked" : "good";

            // Parse end-entity cert to extract serial number
            var certParser = new X509CertificateParser();
            var bcCert = certParser.ReadCertificate(Encoding.ASCII.GetBytes(cert.CertificatePem));
            string serialNumber = bcCert.SerialNumber.ToString(16);

            // 5. Generate OCSP response
            var responseBytes = _ocspService.GenerateOcspResponse(
                serialNumber,
                status,
                intermediate.CertificatePem,              // ✅ Issuer (Intermediate CA cert)
                responder.CertificatePem,                 // ✅ Responder cert
                _keyencryption.Decrypt(responder.EncryptedPrivateKeyPem) // Responder private key
            );

            // 6. Return DER OCSP response
            return File(responseBytes, "application/ocsp-response");
        }


    }
}




