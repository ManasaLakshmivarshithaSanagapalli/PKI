﻿using System.Security.Principal;
using Microsoft.EntityFrameworkCore;
using RootCAAPI.Models;

namespace RootCAAPI.Data
{
    public class OCSPDBContext : DbContext
    {
        public DbSet<OCSPResponder> OcspResponders => Set<OCSPResponder>();

        public OCSPDBContext(DbContextOptions<OCSPDBContext> options) : base(options) { }
    }


}