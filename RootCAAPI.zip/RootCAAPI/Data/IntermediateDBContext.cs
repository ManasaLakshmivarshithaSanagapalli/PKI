﻿using Microsoft.EntityFrameworkCore;
using RootCAAPI.Models;

namespace RootCAAPI.Data
{

    public class IntermediateDBContext : DbContext
    {
        public DbSet<CertificateAuthority> CAs => Set<CertificateAuthority>();

        public IntermediateDBContext(DbContextOptions<IntermediateDBContext> options) : base(options) { }
    }

}

