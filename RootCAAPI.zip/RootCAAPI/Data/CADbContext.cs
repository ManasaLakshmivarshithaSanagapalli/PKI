﻿using Microsoft.EntityFrameworkCore;
using RootCAAPI.Models;

namespace RootCAAPI.Data
{
    public class PkiDbContext : DbContext
    {
        public DbSet<CertificateAuthority> CAs => Set<CertificateAuthority>();
       
        public PkiDbContext(DbContextOptions<PkiDbContext> options) : base(options) { }
    }
}

