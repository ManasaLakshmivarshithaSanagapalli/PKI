﻿using System.Security.Principal;
using Microsoft.EntityFrameworkCore;
using RootCAAPI.Models;

namespace RootCAAPI.Data
{
    public class EndEntityDBContext : DbContext
    {
        public DbSet<EndEntitym> EndEntities => Set<EndEntitym>();

        public EndEntityDBContext(DbContextOptions<EndEntityDBContext> options) : base(options) { }
    }


}
