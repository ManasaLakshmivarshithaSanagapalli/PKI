﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RootCAAPI.Migrations
{
    /// <inheritdoc />
    public partial class ChangeCertificatePem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CertificateDer",
                table: "Certificates");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<byte[]>(
                name: "CertificateDer",
                table: "Certificates",
                type: "varbinary(max)",
                nullable: false,
                defaultValue: new byte[0]);
        }
    }
}
