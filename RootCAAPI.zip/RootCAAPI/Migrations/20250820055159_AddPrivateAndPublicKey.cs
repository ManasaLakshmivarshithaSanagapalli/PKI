﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RootCAAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddPrivateAndPublicKey : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "KeyRef",
                table: "CAs");

            migrationBuilder.AddColumn<string>(
                name: "EncryptedPrivateKeyPem",
                table: "CAs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PublicKeyPem",
                table: "CAs",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EncryptedPrivateKeyPem",
                table: "CAs");

            migrationBuilder.DropColumn(
                name: "PublicKeyPem",
                table: "CAs");

            migrationBuilder.AddColumn<string>(
                name: "KeyRef",
                table: "CAs",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
