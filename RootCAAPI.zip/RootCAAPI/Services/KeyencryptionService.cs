﻿using Microsoft.AspNetCore.DataProtection;

namespace RootCAAPI.Services
{
    public class KeyencryptionService
    {


        private readonly IDataProtector _protector;

        public KeyencryptionService(IDataProtectionProvider provider)
        {
            _protector = provider.CreateProtector("PKI.PrivateKey.Encryption");
        }

        public string Encrypt(string plaintext) => _protector.Protect(plaintext);

        public string Decrypt(string ciphertext) => _protector.Unprotect(ciphertext);
    }
}


