﻿using RootCAAPI.Contracts;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;

namespace RootCAAPI.Services
{
    public class CertificateService
    {
        public (X509Certificate2 cert, AsymmetricAlgorithm key, string algo, int? keySize, string? curve, string privatePem, string publicPem)
            CreateRootCA(CreateRootCaRequest req)
        {
            var algo = (req.Algorithm ?? "RSA").ToUpperInvariant();
            if (algo == "ECC" || algo == "ECDSA")
            {
                var (cert, key, a, ks, c) = CreateRootEcc(req);
                var privPem = ExportPrivateKeyPem((ECDsa)key);
                var pubPem = ExportPublicKeyPem((ECDsa)key);
                return (cert, key, a, ks, c, privPem, pubPem);
            }

            var (certRsa, keyRsa, aRsa, ksRsa, cRsa) = CreateRootRsa(req);
            var privPemRsa = ExportPrivateKeyPem((RSA)keyRsa);
            var pubPemRsa = ExportPublicKeyPem((RSA)keyRsa);
            return (certRsa, keyRsa, aRsa, ksRsa, cRsa, privPemRsa, pubPemRsa);
        }

        private (X509Certificate2, AsymmetricAlgorithm, string, int?, string?) CreateRootRsa(CreateRootCaRequest req)
        {
            int size = req.KeySize ?? 2048; // default
            var key = RSA.Create(size); // Do not dispose here — needs to be returned

            var dn = new X500DistinguishedName(req.SubjectDN);
            var csr = new CertificateRequest(dn, key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            csr.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, true, 0, true));
            csr.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
            csr.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(csr.PublicKey, false));
            var notBefore = DateTimeOffset.UtcNow;
            var notAfter = notBefore.AddYears(req.ValidYears);
            var cert = csr.CreateSelfSigned(notBefore, notAfter);
            return (cert, key, "RSA", size, null);
        }

        private (X509Certificate2, AsymmetricAlgorithm, string, int?, string?) CreateRootEcc(CreateRootCaRequest req)
        {
            var curveName = (req.Curve ?? "nistP256").ToLowerInvariant();
            var curve = curveName switch
            {
                "nistp384" or "p-384" or "p384" => ECCurve.NamedCurves.nistP384,
                "nistp521" or "p-521" or "p521" => ECCurve.NamedCurves.nistP521,
                _ => ECCurve.NamedCurves.nistP256
            };

            var key = ECDsa.Create(curve); // Do not dispose here — needs to be returned
            var dn = new X500DistinguishedName(req.SubjectDN);
            var csr = new CertificateRequest(dn, key, HashAlgorithmName.SHA256);
            csr.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, true, 0, true));
            csr.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
            csr.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(csr.PublicKey, false));
            var notBefore = DateTimeOffset.UtcNow;
            var notAfter = notBefore.AddYears(req.ValidYears);
            var cert = csr.CreateSelfSigned(notBefore, notAfter);
            return (cert, key, "ECC", null, curveName);
        }

        public static string ToPem(byte[] der, string label) =>
           $"-----BEGIN {label}-----\n{Convert.ToBase64String(der, Base64FormattingOptions.InsertLineBreaks)}\n-----END {label}-----\n";

        // 🔐 Export RSA private key
        public static string ExportPrivateKeyPem(RSA rsa)
        {
            var key = rsa.ExportPkcs8PrivateKey();
            return ToPem(key, "PRIVATE KEY");
        }

        public static string ExportPublicKeyPem(RSA rsa)
        {
            var key = rsa.ExportSubjectPublicKeyInfo();
            return ToPem(key, "PUBLIC KEY");
        }

        // 🔐 Export ECDsa private key
        public static string ExportPrivateKeyPem(ECDsa ecdsa)
        {
            var key = ecdsa.ExportPkcs8PrivateKey();
            return ToPem(key, "PRIVATE KEY");
        }

        public static string ExportPublicKeyPem(ECDsa ecdsa)
        {
            var key = ecdsa.ExportSubjectPublicKeyInfo();
            return ToPem(key, "PUBLIC KEY");
        }
        public (X509Certificate2 cert, string certPem, string publicPem, string privatePem, string algo, int? keySize, string? curve)
    CreateIntermediateCA(string subjectDN, string issuerDN, string issuerPrivateKeyPem, string algorithm = "RSA", int? keySize = null, string? curve = null, int validYears = 10)
        {
            algorithm = algorithm.ToUpperInvariant();
            AsymmetricAlgorithm key;
            CertificateRequest csr;

            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var curveUsed = curve?.ToLowerInvariant() ?? "nistp256";
                var ecc = curveUsed switch
                {
                    "nistp384" or "p384" or "p-384" => ECCurve.NamedCurves.nistP384,
                    "nistp521" or "p521" or "p-521" => ECCurve.NamedCurves.nistP521,
                    _ => ECCurve.NamedCurves.nistP256
                };
                key = ECDsa.Create(ecc);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (ECDsa)key, HashAlgorithmName.SHA256);
            }
            else
            {
                var size = keySize ?? 2048;
                key = RSA.Create(size);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (RSA)key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }

            // Extensions for CA
            csr.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, false, 0, true));
            csr.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
            csr.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(csr.PublicKey, false));

            // Load the issuer's private key
            X509SignatureGenerator signer;
            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var issuerKey = ECDsa.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "").Trim()), out _);
                signer = X509SignatureGenerator.CreateForECDsa(issuerKey);
            }
            else
            {
                var issuerKey = RSA.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "").Trim()), out _);
                signer = X509SignatureGenerator.CreateForRSA(issuerKey, RSASignaturePadding.Pkcs1);
            }

            var notBefore = DateTimeOffset.UtcNow;
            var notAfter = notBefore.AddYears(validYears);
            var serial = BitConverter.GetBytes(DateTime.UtcNow.Ticks);

            var cert = csr.Create(new X500DistinguishedName(issuerDN), signer, notBefore, notAfter, serial);

            var certPem = CertificateService.ToPem(cert.Export(X509ContentType.Cert), "CERTIFICATE");

            string privatePem = algorithm == "RSA"
                ? CertificateService.ExportPrivateKeyPem((RSA)key)
                : CertificateService.ExportPrivateKeyPem((ECDsa)key);

            string publicPem = algorithm == "RSA"
                ? CertificateService.ExportPublicKeyPem((RSA)key)
                : CertificateService.ExportPublicKeyPem((ECDsa)key);

            return (cert, certPem, publicPem, privatePem, algorithm, keySize, curve);
        }
        public (X509Certificate2 cert, string certPem, string publicPem, string privatePem, string algo, int? keySize, string? curve)
CreateEndEntity(string subjectDN, string issuerDN, string issuerPrivateKeyPem, string algorithm = "RSA", int? keySize = null, string? curve = null, int validYears = 5)
        {
            algorithm = algorithm.ToUpperInvariant();
            AsymmetricAlgorithm key;
            CertificateRequest csr;

            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var curveUsed = curve?.ToLowerInvariant() ?? "nistp256";
                var ecc = curveUsed switch
                {
                    "nistp384" or "p384" or "p-384" => ECCurve.NamedCurves.nistP384,
                    "nistp521" or "p521" or "p-521" => ECCurve.NamedCurves.nistP521,
                    _ => ECCurve.NamedCurves.nistP256
                };
                key = ECDsa.Create(ecc);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (ECDsa)key, HashAlgorithmName.SHA256);
            }
            else
            {
                var size = keySize ?? 2048;
                key = RSA.Create(size);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (RSA)key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }

            // Extensions for End Entity (not a CA)
            csr.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, false));
            csr.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature | X509KeyUsageFlags.KeyEncipherment, true));
            csr.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(csr.PublicKey, false));

            // Load issuer private key
            X509SignatureGenerator signer;
            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var issuerKey = ECDsa.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "").Trim()), out _);
                signer = X509SignatureGenerator.CreateForECDsa(issuerKey);
            }
            else
            {
                var issuerKey = RSA.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "").Trim()), out _);
                signer = X509SignatureGenerator.CreateForRSA(issuerKey, RSASignaturePadding.Pkcs1);
            }

            var notBefore = DateTimeOffset.UtcNow;
            var notAfter = notBefore.AddYears(validYears);
            var serial = BitConverter.GetBytes(DateTime.UtcNow.Ticks);

            var cert = csr.Create(new X500DistinguishedName(issuerDN), signer, notBefore, notAfter, serial);

            var certPem = CertificateService.ToPem(cert.Export(X509ContentType.Cert), "CERTIFICATE");

            string privatePem = algorithm == "RSA"
                ? CertificateService.ExportPrivateKeyPem((RSA)key)
                : CertificateService.ExportPrivateKeyPem((ECDsa)key);

            string publicPem = algorithm == "RSA"
                ? CertificateService.ExportPublicKeyPem((RSA)key)
                : CertificateService.ExportPublicKeyPem((ECDsa)key);

            return (cert, certPem, publicPem, privatePem, algorithm, keySize, curve);
        }
        public (X509Certificate2 cert, string certPem, string publicPem, string privatePem)
    CreateOcspResponder(string subjectDN, string issuerDN, string issuerPrivateKeyPem, int validYears = 5, string algorithm = "RSA", int? keySize = null, string? curve = null)
        {
            algorithm = algorithm.ToUpperInvariant();
            AsymmetricAlgorithm key;
            CertificateRequest csr;

            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var curveUsed = curve?.ToLowerInvariant() ?? "nistp256";
                var ecc = curveUsed switch
                {
                    "nistp384" or "p384" or "p-384" => ECCurve.NamedCurves.nistP384,
                    "nistp521" or "p521" or "p-521" => ECCurve.NamedCurves.nistP521,
                    _ => ECCurve.NamedCurves.nistP256
                };
                key = ECDsa.Create(ecc);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (ECDsa)key, HashAlgorithmName.SHA256);
            }
            else
            {
                var size = keySize ?? 2048;
                key = RSA.Create(size);
                csr = new CertificateRequest(new X500DistinguishedName(subjectDN), (RSA)key, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            }

            // Extensions specific to OCSP
            csr.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(
                new OidCollection { new Oid("1.3.6.1.5.5.7.3.9") }, false)); // id-kp-OCSPSigning
            csr.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, false));
            csr.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature, true));

            // Load issuer private key (Intermediate CA)
            X509SignatureGenerator signer;
            if (algorithm == "ECC" || algorithm == "ECDSA")
            {
                var issuerKey = ECDsa.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(
                    issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "")
                                       .Replace("-----END PRIVATE KEY-----", "")
                                       .Trim()), out _);
                signer = X509SignatureGenerator.CreateForECDsa(issuerKey);
            }
            else
            {
                var issuerKey = RSA.Create();
                issuerKey.ImportPkcs8PrivateKey(Convert.FromBase64String(
                    issuerPrivateKeyPem.Replace("-----BEGIN PRIVATE KEY-----", "")
                                       .Replace("-----END PRIVATE KEY-----", "")
                                       .Trim()), out _);
                signer = X509SignatureGenerator.CreateForRSA(issuerKey, RSASignaturePadding.Pkcs1);
            }

            var notBefore = DateTimeOffset.UtcNow;
            var notAfter = notBefore.AddYears(validYears);
            var serial = Guid.NewGuid().ToByteArray();

            var cert = csr.Create(new X500DistinguishedName(issuerDN), signer, notBefore, notAfter, serial);
            var certPem = CertificateService.ToPem(cert.Export(X509ContentType.Cert), "CERTIFICATE");

            string privatePem = algorithm == "RSA"
                ? CertificateService.ExportPrivateKeyPem((RSA)key)
                : CertificateService.ExportPrivateKeyPem((ECDsa)key);

            string publicPem = algorithm == "RSA"
                ? CertificateService.ExportPublicKeyPem((RSA)key)
                : CertificateService.ExportPublicKeyPem((ECDsa)key);

            return (cert, certPem, publicPem, privatePem);
        }

    }
}
