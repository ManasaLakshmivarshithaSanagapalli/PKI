﻿using Org.BouncyCastle.Asn1;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Operators;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Ocsp;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System;
using System.IO;
using System.Text;

public class OcspService
{
    public byte[] GenerateOcspResponse(
    string serialNumberHex,
    string status,
    string issuerCertPem,      // 🔹 NEW: Intermediate CA cert
    string responderCertPem,   // 🔹 OCSP cert issued by Intermediate
    string responderKeyPem)
    {
        var certParser = new X509CertificateParser();
        var issuerCert = certParser.ReadCertificate(Encoding.ASCII.GetBytes(issuerCertPem));
        var responderCert = certParser.ReadCertificate(Encoding.ASCII.GetBytes(responderCertPem));

        // Parse private key
        using var reader = new StringReader(responderKeyPem);
        var pemReader = new PemReader(reader);
        var keyObject = pemReader.ReadObject();
        AsymmetricKeyParameter responderKey = keyObject switch
        {
            AsymmetricCipherKeyPair kp => kp.Private,
            AsymmetricKeyParameter key => key,
            _ => throw new Exception("Unsupported private key format.")
        };

        // Build CertID with issuer (Intermediate CA)
        var certId = new CertificateID(
            CertificateID.HashSha1,
            issuerCert,  // ✅ Correct issuer = Intermediate CA
            new BigInteger(serialNumberHex, 16)
        );

        var basicGen = new BasicOcspRespGenerator(responderCert.GetPublicKey());

        if (status.Equals("good", StringComparison.OrdinalIgnoreCase))
            basicGen.AddResponse(certId, CertificateStatus.Good);
        else if (status.Equals("revoked", StringComparison.OrdinalIgnoreCase))
            basicGen.AddResponse(certId, new RevokedStatus(DateTime.UtcNow, CrlReason.PrivilegeWithdrawn));
        else
            basicGen.AddResponse(certId, new UnknownStatus());

        // Detect RSA vs ECC
        string sigAlg = responderKey switch
        {
            RsaKeyParameters or RsaPrivateCrtKeyParameters => "SHA256WITHRSA",
            ECPrivateKeyParameters => "SHA256WITHECDSA",
            _ => throw new InvalidOperationException("Unsupported key type for OCSP responder")
        };

        var sigFactory = new Asn1SignatureFactory(sigAlg, responderKey);
        var basicResp = basicGen.Generate(sigFactory, new[] { responderCert }, DateTime.UtcNow);

        var responseBytes = new ResponseBytes(
            OcspObjectIdentifiers.PkixOcspBasic,
            new DerOctetString(basicResp.GetEncoded())
        );

        var ocspResponse = new OcspResponse(
            new OcspResponseStatus(OcspRespStatus.Successful),
            responseBytes
        );

        return new OcspResp(ocspResponse).GetEncoded();
    }

}
