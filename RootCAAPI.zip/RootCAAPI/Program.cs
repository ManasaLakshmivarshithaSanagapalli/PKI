using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RootCAAPI.Data;
using RootCAAPI.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<PkiDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddDbContext<IntermediateDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("IntermediateConnection")));
builder.Services.AddDbContext<EndEntityDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("endentityConnection")));
builder.Services.AddDbContext<OCSPDBContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("OCSPConnection")));


// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<CertificateService>();
builder.Services.AddDataProtection();
builder.Services.AddScoped<KeyencryptionService>();
builder.Services.AddScoped<OcspService>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp",
        policy => policy
            .WithOrigins("http://localhost:3000") // your React app URL
            .AllowAnyHeader()
            .AllowAnyMethod());
});
builder.Services.AddControllers()
    .AddJsonOptions(opts =>
    {
        opts.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowReactApp");
app.UseAuthorization();

app.MapControllers();

app.Run();
