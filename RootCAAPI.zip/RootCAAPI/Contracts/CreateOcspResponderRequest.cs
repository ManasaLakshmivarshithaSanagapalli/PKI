﻿namespace RootCAAPI.Contracts
{
    public class CreateOcspResponderRequest
    {
            public Guid IntermediateCAId { get; set; }
            public string SubjectDN { get; set; } = string.Empty;
            public int ValidYears { get; set; } = 2;
            public string Algorithm { get; set; } = "RSA";
            public int? KeySize { get; set; }
            public string? Curve { get; set; }

    }
}
