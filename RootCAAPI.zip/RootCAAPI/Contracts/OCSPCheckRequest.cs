﻿namespace RootCAAPI.Contracts
{
    public class OCSPCheckRequest
    {
            public Guid EndEntityCertId { get; set; }
            public Guid IntermediateCAId { get; set; }
    }
}
