﻿namespace RootCAAPI.Contracts
{
    public class CreateEndEntityRequest
    {
        public Guid IssuerId { get; set; } // Intermediate CA Id
        public string Name { get; set; }
        public string SubjectDN { get; set; }
        public string? Algorithm { get; set; } // "RSA" or "ECC"
        public int? KeySize { get; set; }      // For RSA
        public string? Curve { get; set; }     // For ECC
        public int ValidYears { get; set; } = 3;
    }
}
