﻿namespace RootCAAPI.Contracts
{ 
        // Contracts/CreateRootCaRequest.cs
        public class CreateRootCaRequest
        {
            public string Name { get; set; } = "RootCA";
            public string SubjectDN { get; set; } = "CN=Root CA";
            public string Algorithm { get; set; } = "RSA"; // if "RSA" or "ECC" only → defaults kick in
            public int? KeySize { get; set; }      // RSA only; default 2048
            public string? Curve { get; set; }     // ECC only; default nistP256
            public int ValidYears { get; set; } = 20;
        }
}
