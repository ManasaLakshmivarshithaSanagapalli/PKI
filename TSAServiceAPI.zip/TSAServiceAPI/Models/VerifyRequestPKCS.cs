﻿namespace TSAServiceAPI.Models
{
        public class Pkcs7VerifyRequest
        {
            public string Base64Hash { get; set; } = string.Empty;
            public string Timestamp { get; set; } = string.Empty;
            public string Pkcs7Signature { get; set; } = string.Empty;
        }

        public class Pkcs7VerifyResponse
        {
            public bool IsValid { get; set; }
            public string? Message { get; set; }
        }
    
}
