﻿namespace TSAServiceAPI.Models
{
    public class TimeStampRequest
    {
        public string data_hash { get; set; }
        public string algo { get; set; }

    }
}
