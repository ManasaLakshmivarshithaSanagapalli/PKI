﻿namespace TSAServiceAPI.Models
{
    public class TimeStampResponse
    {
        public string Timestamp { get; set; }
        public string Base64Signature { get; set; }
    }
}
