﻿namespace TSAServiceAPI.Models
{
    public class VerifyResponse
    {
        public bool IsValid { get; set; }
    }
}
