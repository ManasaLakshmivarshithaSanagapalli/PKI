﻿namespace TSAServiceAPI.Models
{
    public class VerifyRequest
    {
        public string Base64Hash { get; set; }
        public string Timestamp { get; set; }

        public string Base64Signature { get; set; }

    }
}
