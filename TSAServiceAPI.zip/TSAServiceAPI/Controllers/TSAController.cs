﻿using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TSAServiceApi.Services;
using TSAServiceAPI.Models;
namespace TSAServiceApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TSAController : ControllerBase
    {
        private readonly TSAService _tsaService;
        private readonly TSAValidator _tsaValidator;
        private readonly Pkcs_7Timestamp _pkcs7Service;
        //public TSAController()
        //{
        //    string privateKey = System.IO.File.ReadAllText("Keys/TSA_private.pem");   //for the text document
        //    string publicKey = System.IO.File.ReadAllText("Keys/TSA_public.pem");
        //    _tsaService = new TSAService(privateKey);
        //    _tsaValidator = new TSAValidator(publicKey);
        //}
        public TSAController()
        {
            string privateKey = System.IO.File.ReadAllText("C:/Users/dtuser3/OneDrive/Desktop/PKCS#7/TSA_private.pem"); //for the pkcs#7signature
            string publicKey = System.IO.File.ReadAllText("C:/Users/dtuser3/OneDrive/Desktop/PKCS#7/TSA_public.pem");

            _tsaService = new TSAService(privateKey);
            _tsaValidator = new TSAValidator(publicKey);

            _pkcs7Service = new Pkcs_7Timestamp("C:/Users/dtuser3/OneDrive/Desktop/PKCS#7/TSA_cert.pfx", "1234"); // your password
        }

        [HttpPost("timestamp")]
        public ActionResult<TimeStampResponse> Timestamp([FromBody] TimeStampRequest request)
        {
            var hash = Convert.FromBase64String(request.data_hash);
            var (timestamp, signature) = _tsaService.TimeStampHash(hash);
            return Ok(new TimeStampResponse
            {
                Timestamp = timestamp,
                Base64Signature = Convert.ToBase64String(signature)
            });
        }

        [HttpPost("verify")]
        public ActionResult<VerifyResponse> Verify([FromBody] VerifyRequest request)
        {
            var hash = Convert.FromBase64String(request.Base64Hash);
            var signature = Convert.FromBase64String(request.Base64Signature);
            bool isValid = _tsaValidator.Verify(hash, request.Timestamp, signature);
            return Ok(new VerifyResponse { IsValid = isValid });
        }
        [HttpGet]
        public IActionResult Get()
        {
            
           return Ok("API is running");
        }
        [HttpPost("pkcs7timestamp")]
        public IActionResult Pkcs7Timestamp([FromForm] TimeStampRequest request)
        {
            var hash = Convert.FromBase64String(request.data_hash);
            var algo = "SHA256";
            var (timestamp, _) = _tsaService.TimeStampHash(hash);
            var pkcs7Bytes = _pkcs7Service.GeneratePkcs7(hash, timestamp);

            return Ok(new
            {
                Timestamp = timestamp,
                message = Convert.ToBase64String(pkcs7Bytes)
            });
        }
        [HttpPost("pkcs7verify")]
        public ActionResult<Pkcs7VerifyResponse> VerifyPkcs7Signature([FromBody] Pkcs7VerifyRequest request)
        {
            try
            {
                var hashBytes = Convert.FromBase64String(request.Base64Hash);
                var timestampBytes = Encoding.UTF8.GetBytes(request.Timestamp);
                var combined = hashBytes.Concat(timestampBytes).ToArray();
                var digest = SHA256.HashData(combined);

                var pkcs7Bytes = Convert.FromBase64String(request.Pkcs7Signature);
                var cms = new SignedCms(new ContentInfo(digest), detached: true);
                cms.Decode(pkcs7Bytes);
                cms.CheckSignature(true);

                return Ok(new Pkcs7VerifyResponse { IsValid = true, Message = "Signature is valid." });
            }
            catch (Exception ex)
            {
                return Ok(new Pkcs7VerifyResponse { IsValid = false, Message = "Verification failed: " + ex.Message });
            }
        }


    }
}
