﻿//using System.Security.Cryptography;
//using System.Text;

//namespace TSAServiceApi.Services
//{
//    public class TSAValidator
//    {
//        private readonly RSA _publicRsa;
//        string CleanBase64FromPem(string pem)
//        {
//            return pem
//                .Replace("-----BEGIN PUBLIC KEY-----", "")
//                .Replace("-----END PUBLIC KEY-----", "")
//                .Replace("\r", "")
//                .Replace("\n", "")
//                .Trim();
//        }

//        public TSAValidator(string base64PublicKeyPem)
//        {
//            _publicRsa = RSA.Create();
//            string base64Key = CleanBase64FromPem(base64PublicKeyPem);
//            _publicRsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(base64Key), out _);
//        }

//        //public TSAValidator(string base64PublicKey)
//        //{
//        //    _publicRsa = RSA.Create();
//        //    _publicRsa.ImportSubjectPublicKeyInfo(Convert.FromBase64String(base64PublicKey), out _);
//        //}

//        public bool Verify(byte[] originalHash, string timestamp, byte[] signature)
//        {
//            byte[] timestampBytes = Encoding.UTF8.GetBytes(timestamp);
//            byte[] combined = originalHash.Concat(timestampBytes).ToArray();
//            byte[] digest = SHA256.HashData(combined);
//            return _publicRsa.VerifyData(digest, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
//        }
//    }
//}


using System.Security.Cryptography;
using System.Text;
namespace TSAServiceApi.Services
{
    public class TSAValidator
    {
        private readonly RSA _publicRsa;

        public TSAValidator(string pemPublicKey)
        {
            _publicRsa = RSA.Create();
            _publicRsa.ImportFromPem(pemPublicKey); // Also handles PEM directly
        }

        public bool Verify(byte[] originalHash, string timestamp, byte[] signature)
        {
            byte[] timestampBytes = Encoding.UTF8.GetBytes(timestamp);
            byte[] combined = originalHash.Concat(timestampBytes).ToArray();
            byte[] digest = SHA256.HashData(combined);

            return _publicRsa.VerifyHash(digest, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
        }
    }
}

