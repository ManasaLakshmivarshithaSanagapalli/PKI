﻿//using System.Security.Cryptography;
//using System.Text;

//namespace TSAServiceApi.Services
//{
//    public class TSAService
//    {
//        private readonly RSA _privateRsa;

//        public TSAService(string base64PrivateKey)
//        {
//            _privateRsa = RSA.Create();
//            _privateRsa.ImportPkcs8PrivateKey(Convert.FromBase64String(base64PrivateKey), out _);
//        }

//        public (string Timestamp, byte[] Signature) TimeStampHash(byte[] hashOfData)
//        {
//            string timestamp = DateTime.UtcNow.ToString("o");
//            byte[] timestampBytes = Encoding.UTF8.GetBytes(timestamp);
//            byte[] combined = hashOfData.Concat(timestampBytes).ToArray();
//            byte[] digest = SHA256.HashData(combined);
//            byte[] signature = _privateRsa.SignData(digest, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
//            return (timestamp, signature);
//        }
//    }
//}

using System.Security.Cryptography;
using System.Text;

namespace TSAServiceApi.Services
{
    public class TSAService
    {
        private readonly RSA _privateRsa;

        public TSAService(string pemPrivateKey)
        {
            _privateRsa = RSA.Create();
            _privateRsa.ImportFromPem(pemPrivateKey); // No need to decode Base64
        }

        public (string Timestamp, byte[] Signature) TimeStampHash(byte[] hashOfData)
        {
            string timestamp = DateTime.UtcNow.ToString("o");
            byte[] timestampBytes = Encoding.UTF8.GetBytes(timestamp);
            byte[] combined = hashOfData.Concat(timestampBytes).ToArray();
            byte[] digest = SHA256.HashData(combined);
            byte[] signature = _privateRsa.SignHash(digest, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
            return (timestamp, signature);
        }
    }
}

