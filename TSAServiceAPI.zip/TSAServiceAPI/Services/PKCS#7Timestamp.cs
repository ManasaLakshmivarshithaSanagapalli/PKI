﻿using System.Security.Cryptography.Pkcs;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Text;

namespace TSAServiceApi.Services
{
    public class Pkcs_7Timestamp
    {
        private readonly X509Certificate2 _cert;

        public Pkcs_7Timestamp(string pfxPath, string password)
        {
            _cert = new X509Certificate2(pfxPath, password,
                X509KeyStorageFlags.Exportable | X509KeyStorageFlags.MachineKeySet);
        }

        //public byte[] GeneratePkcs7(byte[] hash, string timestamp)
        //{
        //    var timestampBytes = Encoding.UTF8.GetBytes(timestamp);
        //    var dataToSign = hash.Concat(timestampBytes).ToArray();

        //    ContentInfo contentInfo = new ContentInfo(dataToSign);
        //    SignedCms signedCms = new SignedCms(contentInfo, detached: true);

        //    CmsSigner signer = new CmsSigner(SubjectIdentifierType.IssuerAndSerialNumber, _cert)
        //    {
        //        IncludeOption = X509IncludeOption.EndCertOnly
        //    };

        //    signedCms.ComputeSignature(signer);
        //    return signedCms.Encode();
        //}
        public byte[] GeneratePkcs7(byte[] hash, string timestamp)
        {
            var timestampBytes = Encoding.UTF8.GetBytes(timestamp);
            var dataToSign = hash.Concat(timestampBytes).ToArray();
            var digest = SHA256.HashData(dataToSign);

            ContentInfo contentInfo = new ContentInfo(digest);  // ✅ This ensures digest is signed
            SignedCms signedCms = new SignedCms(contentInfo, detached: true);

            CmsSigner signer = new CmsSigner(SubjectIdentifierType.IssuerAndSerialNumber, _cert)
            {
                IncludeOption = X509IncludeOption.EndCertOnly
            };

            signedCms.ComputeSignature(signer);
            return signedCms.Encode();
        }

    }
}

